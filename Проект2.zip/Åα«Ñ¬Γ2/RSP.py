import os
import random

import pygame

from dialog import Dialog

# инициализация
pygame.init()

# цвета
red = (255, 0, 0)
green = (81, 220, 55)
green_dark = (0, 55, 31)
blue = (0, 0, 255)
black = (0, 0, 0)
yellow = (255, 255, 0)
white = (255, 255, 255)

# экран
ico = pygame.image.load(('icon.jpg'))
pygame.display.set_icon(ico)
screen = pygame.display.set_mode((1024, 900), pygame.FULLSCREEN)
pygame.display.set_caption('камень ножницы бумага')


# текст справки и помощи
def printText(txtText, Textfont, Textsize, Textx, Texty, Textcolor):
    myfont = pygame.font.SysFont(Textfont, Textsize)
    label = myfont.render(txtText, 0, Textcolor)
    screen.blit(label, (Textx, Texty))


# фоны
mm = pygame.image.load(os.path.join("image", "play.png"))
hl = pygame.image.load(os.path.join("image", "play.png"))
ab = pygame.image.load(os.path.join("image", "play.png"))

# Шрифт
menu_font = pygame.font.Font("font\DejaVuSans.ttf", 30)


class Sprite:
    def __init__(self, xpos, ypos, filename):
        self.x = xpos
        self.y = ypos
        self.bitmap = pygame.image.load(os.path.join("image\persons", filename))

    def pers(self):
        screen.blit(self.bitmap, (self.x, self.y))


class Fon:
    def __init__(self, xpos, ypos, filename):
        self.x = xpos
        self.y = ypos
        self.bitmap = pygame.image.load(os.path.join("image", "backgrounds", filename))

    def back(self):
        screen.blit(self.bitmap, (self.x, self.y))


b = True

sudia = Sprite(-50, 200, "sudia.png")

Anya_start = Sprite(520, 140, "Anya_start.png")
Anya = Sprite(520, 140, "Anya_.png")
Anya_f = Sprite(520, 140, "Anya_final.png")
Anya_h = Sprite(520, 140, "Anya_happy.png")
Anya_d = Sprite(520, 190, "lian2.png")

span = Sprite(730, 220, "span_r.png")
span2 = Sprite(730, 220, "span2_r.png")
span3 = Sprite(730, 220, "span3_r.png")

span2_ser = Sprite(350, 180, "span2.png")
span_ser = Sprite(350, 180, "span.png")
span3_ser = Sprite(350, 180, "span3.png")

american_girl = Sprite(190, 165, "am_girl.png")
american_girl2 = Sprite(190, 165, "am_girl2.png")
american_girl3 = Sprite(190, 165, "am_girl3.png")

indus_start = Sprite(400, 250, "indus2.png")
indus_start1 = Sprite(400, 250, "indus.png")
# Индус улыбка
indus = (520, 250, "indus1.png")
# Индус закрытые глаза
indus1 = Sprite(520, 250, "indus2.png")
# Индус грусть
indus2 = Sprite(520, 140, "indus4.png")
indus2_g = Sprite(515, 250, "indus4.png")
# Индус злой
indus3 = Sprite(520, 250, "indus.png")

# в игре
indus_g = Sprite(480, 250, "indus2.png")

# карточки для игры
paper_ = Fon(300, 140, "paper.png")
scissors_ = Fon(300, 140, "scissors.png")
stone_ = Fon(300, 140, "stone.png")
paper_1 = Fon(740, 140, "paper.png")
scissors_1 = Fon(740, 140, "scissors.png")
stone_1 = Fon(740, 140, "stone.png")

# фоны
# начальный экран
bg1 = Fon(0, 0, "bg1.png")
# место проведения турнира
bg2 = Fon(0, 0, "bg2.png")
# здание
bg3 = Fon(0, 0, "bg3.jpg")
# поезд
bg4 = Fon(0, 0, "bg4.png")
# черный экран
bg5 = Fon(0, 0, "black.png")
# станция
bg6 = Fon(0, 0, "bg6.png")
# улица с трибунами
bg7 = Fon(0, 0, "bg5.png")
# белый экран
white_ = Fon(0, 0, "white.png")

# Поражение в конце
end_ = Fon(0, 0, "end.png")
# Победа в конце
end1_ = Fon(0, 0, "end1.png")

# турнирная сетка
grid1 = Fon(50, 125, "grid1.png")

grid2 = Fon(50, 125, "grid2.png")
grid3 = Fon(50, 125, "grid3.png")


class Menu:
    # Покрытие False по-умолчанию
    hovered = False

    # Инициализация строк меню
    def __init__(self, text, pos):
        self.text = text
        self.pos = pos
        self.set_rect()
        self.draw()

    # Рисование и рендер
    def draw(self):
        self.set_rend()
        screen.blit(self.rend, self.rect)

    # Сам рендер
    def set_rend(self):
        self.rend = menu_font.render(self.text, True, self.get_color())

    # Указание цветов (Покрытый\Не покрытый)
    def get_color(self):
        if self.hovered:
            return (red)
        else:
            return ((0, 128, 128))

    # Рендер углов
    def set_rect(self):
        self.set_rend()
        self.rect = self.rend.get_rect()
        self.rect.topleft = self.pos


def helps():
    screen.blit(hl, (0, 0), pygame.FULLSCREEN)
    hlp = True
    while hlp:  # s   x   y
        # printText("Hello World", "DejaVuSans.ttf", 30, 10, 10, red)
        printText("Управление Игрой", "DejaVuSans.ttf", 30, 300, 10, yellow)
        printText("Для продвижения вперед, нажмите пробел или клавишу \"Enter\".", "DejaVuSans.ttf", 30, 140, 30,
                  yellow)
        printText("Для выбора, воспользуйтесь мышью.", "DejaVuSans.ttf", 30, 140, 60, yellow)
        ###
        pygame.display.flip()
        for event in pygame.event.get():
            if event.type == pygame.MOUSEBUTTONDOWN:
                # click.play()
                hlp = False
                mmenu()
            elif event.type == pygame.KEYDOWN:
                # click.play()
                hlp = False
                mmenu()


# Главное Меню
def mmenu():
    # Пункты меню
    menus = [Menu("НАЧАТЬ ИГРУ", (500, 355)),
             Menu("ПОМОЩЬ", (500, 405)),
             Menu("АВТОРЫ", (500, 455)),
             Menu("ВЫХОД", (500, 505))]
    begin = True
    screen.blit(mm, (0, 0))
    # Рабочий цикл
    while begin:
        pygame.event.pump()
        # Проверка пунктов меню
        for menu in menus:
            if menu.rect.collidepoint(pygame.mouse.get_pos()):
                menu.hovered = True
            else:
                menu.hovered = False
            menu.draw()
        pygame.display.flip()
        for event in pygame.event.get():
            if event.type == pygame.MOUSEBUTTONDOWN:
                for menu in menus:
                    if menu.hovered and menu.text == "НАЧАТЬ ИГРУ":
                        print("НОВАЯ ИГРА")
                        novel()

                    elif menu.hovered and menu.text == "ПОМОЩЬ":
                        print("ПОМОЩЬ")
                        helps()

                    elif menu.hovered and menu.text == "АВТОРЫ":
                        print("АВТОРЫ")
                        authors()

                    elif menu.hovered and menu.text == "ВЫХОД":
                        begin = False
                        pygame.quit()


def helps():
    screen.blit(hl, (0, 0))
    hlp = True
    while hlp:  # s   x   y
        # printText("Hello World", "DejaVuSans.ttf", 30, 10, 10, red)
        printText("Управление Игрой", "DejaVuSans.ttf", 30, 300, 10, yellow)
        printText("Для продвижения вперед, нажмите пробел или клавишу \"Enter\".", "DejaVuSans.ttf", 30, 140, 30,
                  yellow)
        printText("Для выбора, воспользуйтесь мышью.", "DejaVuSans.ttf", 30, 140, 60, yellow)

        pygame.display.flip()
        for event in pygame.event.get():
            if event.type == pygame.MOUSEBUTTONDOWN:
                # click.play()
                hlp = False
                mmenu()
            elif event.type == pygame.KEYDOWN:
                # click.play()
                hlp = False
                mmenu()


def authors():
    screen.blit(ab, (0, 0))
    aut = True
    while aut:  # s   x   y
        # printText("Hello World", "DejaVuSans.ttf", 30, 10, 10, red)
        printText(f"Над проектом работали: Гафаров Аяз, Русаков Илья", "DejaVuSans.ttf", 30, 390, 10, yellow)
        printText(f"Автор сценария: Гафаров Аяз", "DejaVuSans.ttf", 30, 430, 35, yellow)
        pygame.display.flip()
        for event in pygame.event.get():
            if event.type == pygame.MOUSEBUTTONDOWN:
                aut = False
                # click.play()
                mmenu()
            elif event.type == pygame.KEYDOWN:
                aut = False
                # click.play()
                mmenu()


def novel():
    ###################################первая игра
    font = pygame.font.Font(None, 72)
    bg1.back()
    # menus = [Menu("Камень", (300, 255)),
    #          Menu("Ножницы", (300, 305)),
    #          Menu("Бумага", (300, 355))]
    # while b == True:
    #     pygame.event.pump()
    #     for menu in menus:
    #         if menu.rect.collidepoint(pygame.mouse.get_pos()):
    #             menu.hovered = True
    #         else:
    #             menu.hovered = False
    #         menu.draw()
    #     pygame.display.flip()
    #     for event in pygame.event.get():
    #         if event.type == pygame.MOUSEBUTTONDOWN:
    #             for menu in menus:
    #                 if menu.hovered and menu.text == "Ножницы":
    #                     scissors()
    #                 elif menu.hovered and menu.text == "Камень":
    #                     stone()
    #                 elif menu.hovered and menu.text == "Бумага":
    #                     paper()
    ##########################################вторая игра

    # menus = [Menu("Камень", (300, 255)),
    #          Menu("Ножницы", (300, 305)),
    #          Menu("Бумага", (300, 355))]
    # while b == True:
    #     pygame.event.pump()
    #     for menu in menus:
    #         if menu.rect.collidepoint(pygame.mouse.get_pos()):
    #             menu.hovered = True
    #         else:
    #             menu.hovered = False
    #         menu.draw()
    #     pygame.display.flip()
    #     for event in pygame.event.get():
    #         if event.type == pygame.MOUSEBUTTONDOWN:
    #             for menu in menus:
    #                 if menu.hovered and menu.text == "Ножницы":
    #                     scissors2()
    #                 elif menu.hovered and menu.text == "Камень":
    #                     stone2()
    #                 elif menu.hovered and menu.text == "Бумага":
    #                     paper2()

    unNoDialog = Dialog(screen)
    unNoDialog.message = ("Эх... порой удача так много решает, что может кординально поменять всю твою жизнь....",)

    unNoDialog.show = True
    unNoDialog.sndNext()
    unNoDialog.message = ("Я 17 летний парень из провинци, который случайно в своем городе наткнулся на турнир"
                          " по ""камень ножницы бумага.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    unNoDialog.message = ("Победив в своем городе, я отправился выступать за свой округю",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    unNoDialog.message = ("Где так же одержал"
                          " сухую победу над всеми оппонентами.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    unNoDialog.message = ("Затем и чемпионат России...",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    unNoDialog.message = ("И вот сейчас... я еду в Москву, на чемпионат Мира...",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    unNoDialog.message = ("Хе-хе-хе... как же после этого не назвать меня везунчиком?.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    unNoDialog.message = ("Но порой меня охватывает странное чувство будто "
                          "сама судьба направляла меня к этому момету.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    unNoDialog.message = ("Надеюсь я смогу одолеть хотя бы парочку противников....",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    unNoDialog.message = ("(кто то толкает в бок главного героя).",)
    bg4.back()
    unNoDialog.show = True
    unNoDialog.sndNext()
    unNoDialog.message = ("-???- = Эй, вставай, мы скоро подъедем!.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    unNoDialog.message = ("-мысли- = Открыв глаза, перед моим взором востал силуэт милой девченки.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    Anya_start.pers()
    unNoDialog.sndNext()
    unNoDialog.message = ("-мысли- = Это была моя подруга детства, Аня.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    unNoDialog.message = ("-мысли- = С самого начала этого пути она была со мной и поддерживала меня.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    unNoDialog.message = ("-мысли- = Так же она хороша в психологии и часто давала мне советы,"
                          " благодаря которым я одерживал победу.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    unNoDialog.message = ("-Серега- = Что, мы уже в Москве?.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    bg4.back()
    Anya.pers()
    unNoDialog.message = ("-Аня- = Конечно, ты проспал весь наш путь, небось всю ночь опять играл в свои игры....",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    unNoDialog.message = ("-мысли- = Так и есть, но эти слова будто затронули мою гордость.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    unNoDialog.message = ("-Серега- = С чего ты взяла?.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    bg4.back()
    Anya_h.pers()
    unNoDialog.message = ("-Аня- = Да на твоем лице все написано!.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    unNoDialog.message = ("-Аня- = хи-хи-хи.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    unNoDialog.message = ("-мысли- = Каждый раз когда я слышу ее милый смех,"
                          " он будто наполняет меня неким зарядом счастья.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    unNoDialog.message = ("-Серега- = Ладно, проехали...",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    unNoDialog.message = ("-Серега- = Скорее бы узнать кто мой первый соперник.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    bg4.back()
    Anya_d.pers()
    bg5.back()
    printText("Некоторе время спустя......", "DejaVuSans.ttf", 110, 60, 400, red)
    unNoDialog.message = ("-Аня- = Да уж... Пошли уже, наша станция.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    bg6.back()
    unNoDialog.message = ("-мысли- Мы потихоньку вышли с транспорта и направились в сторону место проведения турнира.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    bg5.back()
    unNoDialog.message = ("-мысли- Я был настолько в облаках, что не заметил как уже оказался в здании.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    bg3.back()
    unNoDialog.message = ("-мысли- Вся моя голова была забита мыслями о победе.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    unNoDialog.message = ("-мысли- Тут было много народа и сплошной шум... Бесит!.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    unNoDialog.message = ("На турнире России было примерно столько же, но даже там не было так шумно.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    Anya_start.pers()
    unNoDialog.message = ("-Серега- Аня, пошли посмотрим на сетку и быстрее пройдем на нашу площадку.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    unNoDialog.message = ("-Аня- согласна, не люблю этих СМИ.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    unNoDialog.message = ("Подойдя к стенду, мы увидели следующее.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    white_.back()
    grid1.back()
    unNoDialog.message = ("-мысли- Значит первая игра будет с Индией, в прошлом году она была на 3 месте..",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    unNoDialog.message = ("-мысли- Я потихоньку начал нервничать, пытаясь не показать это Ане, я промолвил.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    unNoDialog.message = ("-Серега- Могло быть и лучше.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    bg3.back()
    Anya.pers()
    unNoDialog.message = ("-Аня- Уже подсознательно сдался?.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    unNoDialog.message = ("-Серега- Нет конечно, просто как то не по себе....",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    unNoDialog.message = ("-Аня- Да ладно тебе, главное не паникуй и думай о победе!.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    unNoDialog.message = ("-Серега- Хорошо, пошли!.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    bg3.back()
    Anya_start.pers()
    unNoDialog.message = ("-Аня- Угу.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    bg2.back()
    unNoDialog.message = ("(Мы направились на нашу площадку, где меня уже ожидал оппонент и судья).",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    sudia.pers()
    indus_start.pers()
    unNoDialog.message = ("-судья- Обе стороны пришли, можете начинать первый раунд.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    bg2.back()
    sudia.pers()
    indus_start.pers()
    unNoDialog.message = ("-индус- Явился всё-таки....",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    unNoDialog.message = ("-мысли- Хоть я его впервые вижу, мне кажется, он слишком высокого мнения о себе....",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    unNoDialog.message = ("-мысли- Его самоувереность бесит меня!.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    bg2.back()
    Anya_d.pers()
    unNoDialog.message = ("-Аня- Честно говоря, не нравится мне этот тип....",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    unNoDialog.message = ("-Серега- Соглашусь.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    bg2.back()
    indus2.pers()
    unNoDialog.message = ("-индус- ЧТО ВЫ ТАМ ШЕПЧЕТЕСЬ!!!.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    unNoDialog.message = ("-индус- Я НЕ ПОТЕРПЛЮ НАСМЕШЕК В МОЮ СТОРОНУ!!!.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    unNoDialog.message = ("-Серега- Извините, тактику просто обсуждали.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    bg2.back()
    indus_g.pers()
    unNoDialog.message = ("-индус- Что с вами поделать....",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    unNoDialog.message = ("-судья- НАЧИНАЕМ.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    unNoDialog.message = ("-Аня- Удачи тебе!.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    unNoDialog.message = ("-Серега- Угу, она мне явно понадобится.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    unNoDialog.message = ("-мысли- Я встал на против своего противника, достал карточки для игры и"
                          "в своей голове уже понял что буду ставить...",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    menus = [Menu("Камень", (300, 255)),
             Menu("Ножницы", (300, 305)),
             Menu("Бумага", (300, 355))]
    while b == True:
        pygame.event.pump()
        for menu in menus:
            if menu.rect.collidepoint(pygame.mouse.get_pos()):
                menu.hovered = True
            else:
                menu.hovered = False
            menu.draw()
        pygame.display.flip()
        for event in pygame.event.get():
            if event.type == pygame.MOUSEBUTTONDOWN:
                for menu in menus:
                    if menu.hovered and menu.text == "Ножницы":
                        scissors()

                    elif menu.hovered and menu.text == "Камень":
                        stone()

                    elif menu.hovered and menu.text == "Бумага":
                        paper()


# Бумага
def paper():
    font = pygame.font.Font(None, 72)
    bg2.back()
    indus_g.pers()
    unNoDialog = Dialog(screen)
    unNoDialog.message = ("-мысли- Моим ходом будет БУМАГА.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    paper_.back()
    unNoDialog.message = ("-мысли- Покажу этому высокомерному придурку свой гибкий разум.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    paper_.back()
    pc()


# Ножницы
def scissors():
    font = pygame.font.Font(None, 72)
    bg2.back()
    indus_g.pers()
    unNoDialog = Dialog(screen)
    unNoDialog.message = ("-мысли- Моим ходом будет НОЖНИЦЫ.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    scissors_.back()
    unNoDialog.message = ("-мысли- Покажу этому индусу как опасно со мной возиться.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    scissors_.back()
    scc()


# Камень
def stone():
    font = pygame.font.Font(None, 72)
    bg2.back()
    indus_g.pers()
    unNoDialog = Dialog(screen)
    unNoDialog.message = ("-мысли- Моим ходом будет КАМЕНЬ.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    stone_.back()
    unNoDialog.message = ("-мысли- Покажу этому зазнайке свой твердый и жесткий характер!!!.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    stone_.back()
    sc()


# продолжаем...
def scc():
    sps = ['камень', 'ножницы', 'бумага']
    a = random.choice(sps)
    if a == 'камень':
        stone_1.back()
        unNoDialog = Dialog(screen)
        unNoDialog.message = ("ЧЕЕЕРТ.",)
        unNoDialog.show = True
        unNoDialog.sndNext()
        unNoDialog.message = ("ОН ПОСТАВИЛ КАМЕНЬ.",)
        unNoDialog.show = True
        unNoDialog.sndNext()
        unNoDialog.message = ("Я ПРОИГРАЛ.",)
        unNoDialog.show = True
        unNoDialog.sndNext()
        loose()

    elif a == 'ножницы':
        scissors_1.back()
        draw()


    elif a == 'бумага':

        bg2.back()
        indus2_g.pers()
        scissors_.back()
        paper_1.back()
        unNoDialog = Dialog(screen)
        unNoDialog.message = ("УРААА.",)
        unNoDialog.show = True
        unNoDialog.sndNext()
        unNoDialog.message = ("ОН ПОСТАВИЛ БУМАГУ.",)
        unNoDialog.show = True
        unNoDialog.sndNext()
        unNoDialog.message = ("ОН ПРОИГРАЛ.",)
        unNoDialog.show = True
        unNoDialog.sndNext()
        unNoDialog.message = ("Я смог одолеть его!!!.",)
        unNoDialog.show = True
        unNoDialog.sndNext()
        continue_()


def sc():
    sps = ['камень', 'ножницы', 'бумага']
    a = random.choice(sps)
    if a == 'камень':
        stone_1.back()
        draw()

    elif a == 'ножницы':
        bg2.back()
        indus2_g.pers()
        stone_.back()
        scissors_1.back()
        unNoDialog = Dialog(screen)
        unNoDialog.message = ("ПОВЕЗЛО.......",)
        unNoDialog.show = True
        unNoDialog.sndNext()
        unNoDialog.message = ("ОН ПОСТАВИЛ НОЖНИЦЫ.",)
        unNoDialog.show = True
        unNoDialog.sndNext()
        unNoDialog.message = ("Я ВЫЙГРАЛ.",)
        unNoDialog.show = True
        unNoDialog.sndNext()
        continue_()

    elif a == 'бумага':
        paper_1.back()
        unNoDialog = Dialog(screen)
        unNoDialog.message = ("ЧЕЕЕРТ.",)
        unNoDialog.show = True
        unNoDialog.sndNext()
        unNoDialog.message = ("ОН ПОСТАВИЛ БУМАГУ.",)
        unNoDialog.show = True
        unNoDialog.sndNext()
        unNoDialog.message = ("Я ПРОИГРАЛ.",)
        unNoDialog.show = True
        unNoDialog.sndNext()
        loose()


def pc():
    sps = ['камень', 'ножницы', 'бумага']
    a = random.choice(sps)
    if a == 'камень':
        bg2.back()
        indus2_g.pers()
        paper_.back()
        stone_1.back()
        unNoDialog = Dialog(screen)
        unNoDialog.message = ("УРААА.",)
        unNoDialog.show = True
        unNoDialog.sndNext()
        unNoDialog.message = ("ОН ПОСТАВИЛ КАМЕНЬ.",)
        unNoDialog.show = True
        unNoDialog.sndNext()
        unNoDialog.message = ("Я ВЫЙГРАЛ, ЭТО БЫЛО ДОВОЛЬНО ЛЕГКО.",)
        unNoDialog.show = True
        unNoDialog.sndNext()
        continue_()

    elif a == 'ножницы':
        scissors_1.back()
        unNoDialog = Dialog(screen)
        unNoDialog.message = ("ЧЕЕЕРТ.",)
        unNoDialog.show = True
        unNoDialog.sndNext()
        unNoDialog.message = ("ОН ПОСТАВИЛ НОЖНИЦЫ.",)
        unNoDialog.show = True
        unNoDialog.sndNext()
        unNoDialog.message = ("Я ПРОИГРАЛ!!!.",)
        unNoDialog.show = True
        unNoDialog.sndNext()
        loose()

    elif a == 'бумага':
        paper_1.back()
        draw()


def draw():
    unNoDialog = Dialog(screen)
    unNoDialog.message = ("ЭТО НИЧЬЯ.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    unNoDialog = Dialog(screen)
    unNoDialog.message = ("А ЗНАЧИТ ПРИДЕТСЯ ВЫБРАТЬ ЕЩЕ РАЗ.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    bg2.back()
    indus_g.pers()


def draw2():
    unNoDialog = Dialog(screen)
    unNoDialog.message = ("ЭТО НИЧЬЯ.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    unNoDialog = Dialog(screen)
    unNoDialog.message = ("А ЗНАЧИТ ПРИДЕТСЯ ВЫБРАТЬ ЕЩЕ РАЗ.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    bg2.back()
    span2_ser.pers()


def scissors2():
    bg2.back()
    span2_ser.pers()
    unNoDialog = Dialog(screen)
    scissors_.back()
    unNoDialog.message = ("-мысли- Моим ходом будет НОЖНИЦЫ!",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    scc2()


def paper2():
    font = pygame.font.Font(None, 72)
    bg2.back()
    span2_ser.pers()
    unNoDialog = Dialog(screen)
    paper_.back()
    unNoDialog.message = ("-мысли- Моим ходом будет БУМАГА.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    pc2()


def stone2():
    font = pygame.font.Font(None, 72)
    bg2.back()
    span2_ser.pers()
    unNoDialog = Dialog(screen)
    stone_.back()
    unNoDialog.message = ("-мысли- Моим ходом будет КАМЕНЬ.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    sc2()


def scc2():
    sps = ['камень', 'ножницы', 'бумага']
    a = random.choice(sps)
    if a == 'камень':
        stone_1.back()
        unNoDialog = Dialog(screen)
        unNoDialog.message = ("ЧЕЕЕРТ.",)
        unNoDialog.show = True
        unNoDialog.sndNext()
        unNoDialog.message = ("ОН ПОСТАВИЛ КАМЕНЬ.",)
        unNoDialog.show = True
        unNoDialog.sndNext()
        unNoDialog.message = ("Я ПРОИГРАЛ.",)
        unNoDialog.show = True
        unNoDialog.sndNext()
        loose()

    elif a == 'ножницы':
        scissors_1.back()
        draw2()

    elif a == 'бумага':
        paper_1.back()
        unNoDialog = Dialog(screen)
        unNoDialog.message = ("УРААА.",)
        unNoDialog.show = True
        unNoDialog.sndNext()
        unNoDialog.message = ("ОН ПОСТАВИЛ БУМАГУ.",)
        unNoDialog.show = True
        unNoDialog.sndNext()
        unNoDialog.message = ("ОН ПРОИГРАЛ.",)
        unNoDialog.show = True
        unNoDialog.sndNext()
        unNoDialog.message = ("Я смог одолеть его!!!.",)
        unNoDialog.show = True
        unNoDialog.sndNext()
        american_boy()


def sc2():
    sps = ['камень', 'ножницы', 'бумага']
    a = random.choice(sps)
    if a == 'камень':
        stone_1.back()
        draw2()

    elif a == 'ножницы':
        scissors_1.back()
        unNoDialog = Dialog(screen)
        unNoDialog.message = ("ПОВЕЗЛО.......",)
        unNoDialog.show = True
        unNoDialog.sndNext()
        unNoDialog.message = ("ОН ПОСТАВИЛ НОЖНИЦЫ.",)
        unNoDialog.show = True
        unNoDialog.sndNext()
        unNoDialog.message = ("Я ВЫЙГРАЛ.",)
        unNoDialog.show = True
        unNoDialog.sndNext()
        american_boy()

    elif a == 'бумага':
        paper_1.back()
        unNoDialog = Dialog(screen)
        unNoDialog.message = ("ЧЕЕЕРТ.",)
        unNoDialog.show = True
        unNoDialog.sndNext()
        unNoDialog.message = ("ОН ПОСТАВИЛ БУМАГУ.",)
        unNoDialog.show = True
        unNoDialog.sndNext()
        unNoDialog.message = ("Я ПРОИГРАЛ.",)
        unNoDialog.show = True
        unNoDialog.sndNext()
        loose()


def pc2():
    sps = ['камень', 'ножницы', 'бумага']
    a = random.choice(sps)
    if a == 'камень':
        stone_1.back()
        unNoDialog = Dialog(screen)
        unNoDialog.message = ("УРААА.",)
        unNoDialog.show = True
        unNoDialog.sndNext()
        unNoDialog.message = ("ОН ПОСТАВИЛ КАМЕНЬ.",)
        unNoDialog.show = True
        unNoDialog.sndNext()
        unNoDialog.message = ("Я ВЫЙГРАЛ.",)
        unNoDialog.show = True
        unNoDialog.sndNext()
        american_boy()

    elif a == 'ножницы':
        scissors_1.back()
        unNoDialog = Dialog(screen)
        unNoDialog.message = ("ЧЕЕЕРТ.",)
        unNoDialog.show = True
        unNoDialog.sndNext()
        unNoDialog.message = ("ОН ПОСТАВИЛ НОЖНИЦЫ.",)
        unNoDialog.show = True
        unNoDialog.sndNext()
        unNoDialog.message = ("Я ПРОИГРАЛ!!!.",)
        unNoDialog.show = True
        unNoDialog.sndNext()
        loose()

    elif a == 'бумага':
        paper_1.back()
        draw2()


# и снова продолжение.....
def continue_():
    bg2.back()
    indus2_g.pers()
    unNoDialog = Dialog(screen)
    unNoDialog.message = ("-Индус- КАК ТАК?! КАК ТЫ СУМЕЛ ОДОЛЕТЬ МЕНЯ?!.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    bg2.back()
    indus2.pers()
    continue1()


def continue1():
    unNoDialog = Dialog(screen)
    unNoDialog.message = ("-Серега- Спасибо за игру, дружище!!!.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    unNoDialog.message = ("-Индус- ЧТОБ ТЕБЯ!.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    bg2.back()
    Anya_h.pers()
    unNoDialog.message = ("-Аня- УРА! Я так рада за тебя!.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    bg2.back()
    Anya_f.pers()
    unNoDialog.message = ("Спасибо, Аня! Без тебя бы я не справился!.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    bg2.back()
    unNoDialog.message = ("-мысли- В момент я подумал, что я могу свернуть горы, "
                          "но мои мысли остановил голос судьи...",)
    unNoDialog.show = True
    bg2.back()
    sudia.pers()
    unNoDialog.sndNext()
    unNoDialog.message = ("-судья- Поздравляю, вы проходите дальше к следующей игре!.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    unNoDialog.message = ("-Серега- хорошо.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    unNoDialog.message = ("-мысли- После победы над индусом, долго радоваться нам не пришлось..",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    bg3.back()
    unNoDialog.message = ("-мысли- Выйдя обратно с арены, я посмотрел на турнирную сетку.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    white_.back()
    grid2.back()
    unNoDialog.message = ("-Серега- Значит мой следующий соперник это Испанец.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    unNoDialog.message = ("-Аня- В прошлом году, Испания особых успехов не добилась.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    unNoDialog.message = ("-Аня- Но говорят, что в этом, она победила бывшего финалиста....",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    unNoDialog.message = ("-Аня- Она победила Китай..",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    bg3.back()
    Anya.pers()
    unNoDialog.message = ("-серега- эх.... блин... как то страшно чтоль...",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    bg3.back()
    Anya_h.pers()
    unNoDialog.message = ("-Аня- Да не переживай, дурачек, Индию ты тоже боялся, а вон как себя проявил....",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    unNoDialog.message = ("-мысли- Она права, рано отпускать руки....",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    unNoDialog.message = ("В этот момент я почувствовал легкий толчок в спину.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    bg3.back()
    unNoDialog.message = ("-???- Простите, я не специально!.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    span2_ser.pers()
    unNoDialog.message = ("Повернувшись я увидел светловолосого блондина, высокого роста.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    unNoDialog.message = ("Его голубые глаза были уставлены на меня.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    bg3.back()
    span.pers()
    Anya_start.pers()
    unNoDialog.message = ("-???- О, вы же представитель России!.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    unNoDialog.message = ("-???- Примите мои поздравления!.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    unNoDialog.message = ("-Серега- Спасибо огромное!.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    bg3.back()
    span.pers()
    Anya_d.pers()
    unNoDialog.message = ("-Аня- Слушайте....",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    unNoDialog.message = ("-Аня- Ваше лицо мне кажется очень знакомым....",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    bg3.back()
    span3.pers()
    Anya.pers()
    unNoDialog.message = ("-???- Да ну что вы, я впервые вас вижу.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    unNoDialog.message = ("После недолгой паузы, незнакомец обратился ко мне.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    bg3.back()
    span2_ser.pers()
    unNoDialog.message = ("-???- Разрешите мне взглянуть на таблицу?.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    unNoDialog.message = ("-Серега- Ой, простите, прошу.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    bg3.back()
    unNoDialog.message = ("Я отошел в сторону, чтоб дать ему посмотреть на сетку.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    span_ser.pers()
    unNoDialog.message = ("-???- Так вот значит как....",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    bg3.back()
    span3_ser.pers()
    unNoDialog.message = ("-???- Ну, мне пора!.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    unNoDialog.message = ("-Серега- Удачи вам!.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    unNoDialog.message = ("-???- Спасибо! Скоро увидимся!.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    bg3.back()
    unNoDialog.message = ("После этих слов, незнакомец ушел, оставив меня в недоумении.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    Anya_start.pers()
    unNoDialog.message = ("-Серега- Что значит скоро увидимся?.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    bg3.back()
    Anya_h.pers()
    unNoDialog.message = ("-Аня- Не морочь себе голову.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    unNoDialog.message = ("-Серега- Да, пожалуй так и сделаю.....",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    unNoDialog.message = ("До игры оставалось 30 минут, и я решил вздремнуть.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    bg5.back()
    unNoDialog.message = ("Закрыв глаза я начал думать о том, что будет после победы.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    unNoDialog.message = ("На самом деле, я очень давно хотел признаться Ане....",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    unNoDialog.message = ("Да, все это время я был в нее влюблен....",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    unNoDialog.message = ("А может признаться ей если смогу всех победить?.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    unNoDialog.message = ("Да не, думаю это глупо....",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    unNoDialog.message = ("Хотя....",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    unNoDialog.message = ("(кто то трясет главного героя).",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    bg3.back()
    Anya_start.pers()
    unNoDialog.message = ("Открыв глаза я опять увидел её.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    bg3.back()
    Anya_h.pers()
    unNoDialog.message = ("-Аня- Ну что, пошли!.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    unNoDialog.message = ("-Серега- Конечно!.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    bg5.back()
    unNoDialog.message = ("После этих слов, мы отправились на назначенное место...",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    unNoDialog.message = ("Придя к знакомой для меня арены, я увидел только судью.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    bg2.back()
    sudia.pers()
    unNoDialog.message = ("-Судья- Аппонент еще не пришел, если он не явится следующие 5 минут.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    unNoDialog.message = ("-Судья- То придется засчитать вам техническую победу.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    bg2.back()
    Anya_h.pers()
    unNoDialog.message = ("-Аня- Будет круто! Хе-хе-хе.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    unNoDialog.message = ("-Серега- Тогда я точно попаду в финал!.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    unNoDialog.message = ("-Мысли- Я буду очень рад такому раскладу событий....",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    unNoDialog.message = ("Слышны приближающиеся шаги за моей спиной.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    bg2.back()
    unNoDialog.message = ("-???- Простите, задержался, эти фанатки такие приставучие!.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    unNoDialog.message = ("Посмотрев назад, я понял кто является моим соперником.",)
    unNoDialog.show = True
    span2_ser.pers()
    unNoDialog.sndNext()
    unNoDialog.message = ("-Испанец- И снова здравствуй, Сергей.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    bg2.back()
    span_ser.pers()
    unNoDialog.message = ("-Испанец- Хихихи.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    bg2.back()
    Anya.pers()
    unNoDialog.message = ("-Аня- Так вот где я тебя видела!!!.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    bg2.back()
    Anya_d.pers()
    unNoDialog.message = ("-Аня- Ты же появлялся на журналах как самый горячий участник!.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    bg2.back()
    span2_ser.pers()
    unNoDialog.message = ("-Испанец- Не заставляй меня смущаться.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    bg2.back()
    span_ser.pers()
    sudia.pers()
    unNoDialog.message = ("-Судья- Обе стороны прибыли, готовтесь к игре!.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    bg2.back()
    span3_ser.pers()
    unNoDialog.message = ("-Испанец- Окей.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    bg2.back()
    Anya_h.pers()
    unNoDialog.message = ("-Аня- Удачки тебе!.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    unNoDialog.message = ("-Серега- Угу, я не подведу!.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    bg2.back()
    span_ser.pers()
    unNoDialog.message = ("-Серега- Ну что, понеслась!.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    bg2.back()
    span3_ser.pers()
    unNoDialog.message = ("-Испанец- Попробуй одолей меня!.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    bg2.back()
    span3_ser.pers()
    pygame.display.flip()
    menus = [Menu("Камень", (300, 255)),
             Menu("Ножницы", (300, 305)),
             Menu("Бумага", (300, 355))]
    while b == True:
        pygame.event.pump()
        for menu in menus:
            if menu.rect.collidepoint(pygame.mouse.get_pos()):
                menu.hovered = True
            else:
                menu.hovered = False
            menu.draw()
        pygame.display.flip()
        for event in pygame.event.get():
            if event.type == pygame.MOUSEBUTTONDOWN:
                for menu in menus:
                    if menu.hovered and menu.text == "Ножницы":
                        scissors2()
                    elif menu.hovered and menu.text == "Камень":
                        stone2()
                    elif menu.hovered and menu.text == "Бумага":
                        paper2()


def american_boy():
    bg2.back()
    unNoDialog = Dialog(screen)
    unNoDialog.message = ("-Серега-.....",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    Anya_start.pers()
    unNoDialog.message = ("-Аня-....",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    bg2.back()
    span2_ser.pers()
    unNoDialog.message = ("-Испанец-.....",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    bg2.back()
    sudia.pers()
    unNoDialog.message = ("-Судья- Поздравляю, Россия проходит в финал!.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    Anya_h.pers()
    unNoDialog.message = ("-Аня- УРАААААА!.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    unNoDialog.message = ("-Серега- ПОБЕДА!!!!!!!.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    span3.pers()
    unNoDialog.message = ("-Испанец- Мои поздравления, joven ganador(юный победитель)!.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    unNoDialog.message = ("-Испанец- Adiós mi amigo(прощай, мой друг).",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    unNoDialog.message = ("После этих слов он развернулся и неторопливом шагом вышел с арены.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    bg2.back()
    sudia.pers()
    Anya_h.pers()
    unNoDialog.message = ("Первое мое выступление, а уже финал....",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    unNoDialog.message = ("Я не мог в это поверить....",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    unNoDialog.message = ("А что дальше?.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    bg2.back()
    Anya_f.pers()
    unNoDialog.message = ("Увидев довольное лицо Ани, я сам невольно начал улыбаться....",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    unNoDialog.message = ("-Аня- Я так рада за тебя!.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    unNoDialog.message = ("Сказала она сквозь слезы",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    unNoDialog.message = ("-Серега- Не плачь, прошу.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    unNoDialog.message = ("Она вытерла с щек слезы и пыталась сделать серьезный вид.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    bg2.back()
    Anya_start.pers()
    unNoDialog.message = ("-Мысли- Точно... Финал....",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    unNoDialog.message = ("-Мысли- А кто интересно против меня?.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    unNoDialog.message = ("-???- Так-так-так.....",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    unNoDialog.message = ("-???- Вот кого я значит следующего обыграю.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    final()


def final():
    bg2.back()
    unNoDialog = Dialog(screen)
    unNoDialog.message = ("Я повернулся на громкий и очень уверенный голос, который доносился с конца арены.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    american_girl.pers()
    unNoDialog.message = ("Рассмотрев ее, я понял кто мой будущий соперник.....",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    bg2.back()
    american_girl2.pers()
    unNoDialog.message = ("-Американка- Скукота, ну да ладно....",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    bg2.back()
    american_girl.pers()
    unNoDialog.message = ("-Американка- Тебе меня не одолеть, можешь сразу сдаваться!.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    unNoDialog.message = ("-Серега- .....",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    unNoDialog.message = ("-Серега- Кто ребенка потерял?.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    bg2.back()
    american_girl3.pers()
    unNoDialog.message = ("-Американка- Я НЕ РЕБЕНОК!!!.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    unNoDialog.message = ("-Серега- .....",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    unNoDialog.message = ("-Серега- Ладно-ладно....",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    bg2.back()
    american_girl2.pers()
    unNoDialog.message = ("-Американка- К твоему сведению, я трёхкратная чемпионка мира!.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    unNoDialog.message = ("Эти слова действительно напугали меня, но я не подал виду.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    unNoDialog.message = ("-Серега- Тогда давай поспорим что я выйграю!.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    bg2.back()
    american_girl.pers()
    unNoDialog.message = ("-Американка- Давай, если победишь, то я....",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    win()


# победа
def win():
    screen.fill((0, 0, 0))
    end1_.back()
    end()


# конец
def end():
    unNoDialog = Dialog(screen)
    unNoDialog.message = ("СПАСИБО ЗА ТО ЧТО ДОШЛИ ДО КОНЦА.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    unNoDialog.message = ("НАДЕЕМСЯ ВАМ ПОНРАВИЛОСЬ.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    unNoDialog.message = ("АВТОРЫ ИГРЫ ГАФАРОВ АЯЗ И РУСАКОВ ИЛЬЯ.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    screen.fill((0, 0, 0))
    pygame.display.flip()
    mmenu()


# проигрыш
def loose():
    unNoDialog = Dialog(screen)
    screen.fill('black')
    unNoDialog.message = ("-мысли- увидев довольное лицо своего врага, я закрыл глаза....",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    unNoDialog.message = ("-мысли- неужели на этом все закончиться, неужели я больше ничего не смогу?.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    unNoDialog.message = ("-мысли- уйдя в себя... я уже ничего не слышал....",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    end_.back()
    unNoDialog.message = ("ВЫ ПРОИГРАЛИ.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    end()


def main():
    mmenu()
    begin = True
    keys = pygame.key.get_pressed()
    while begin:
        for event in pygame.event.get():
            if event.type == pygame.KEYDOWN:
                if event.key == keys[pygame.K_ESCAPE]:
                    begin = False
                    pygame.quit()
                    break

            if event.type == pygame.QUIT:
                begin = False
                pygame.quit()
                break


# Запуск программы
if __name__ == "__main__":
    main()
