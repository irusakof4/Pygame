import os
import random

import pygame

from dialog import Dialog

# инициализация
pygame.init()

# цвета
red = (255, 0, 0)
green = (81, 220, 55)
green_dark = (0, 55, 31)
blue = (0, 0, 255)
black = (0, 0, 0)
yellow = (255, 255, 0)
white = (255, 255, 255)

# экран
ico = pygame.image.load(('icon.png'))
icon = pygame.transform.scale(ico, (32, 32))
pygame.display.set_icon(icon)
screen = pygame.display.set_mode((1024, 900), pygame.FULLSCREEN)
pygame.display.set_caption('камень ножницы бумага')


# текст справки и помощи
def printText(txtText, Textfont, Textsize, Textx, Texty, Textcolor):
    myfont = pygame.font.SysFont(Textfont, Textsize)
    label = myfont.render(txtText, 0, Textcolor)
    screen.blit(label, (Textx, Texty))


# фоны
mm = pygame.image.load(os.path.join("image", "play.png"))
hl = pygame.image.load(os.path.join("image", "play.png"))
ab = pygame.image.load(os.path.join("image", "play.png"))

# Шрифт
menu_font = pygame.font.Font("font\DejaVuSans.ttf", 30)


# Музыка
# click = pygame.mixer.Sound(os.path.join('audio', 'click.wav'))


class Sprite:
    def __init__(self, xpos, ypos, filename):
        self.x = xpos
        self.y = ypos
        self.bitmap = pygame.image.load(os.path.join("image\persons", filename))

    def pers(self):
        screen.blit(self.bitmap, (self.x, self.y))


class Fon:
    def __init__(self, xpos, ypos, filename):
        self.x = xpos
        self.y = ypos
        self.bitmap = pygame.image.load(os.path.join("image", "backgrounds", filename))

    def back(self):
        screen.blit(self.bitmap, (self.x, self.y))


b = True

sudia = Sprite(520, 200, "sudia.png")

Anya_start = Sprite(520, 140, "Anya_start.png")
Anya = Sprite(520, 140, "Anya_.png")
Anya_f = Sprite(520, 140, "Anya_final.png")
Anya_h = Sprite(520, 140, "Anya_happy.png")
Anya_d = Sprite(520, 190, "lian2.png")

span = Sprite(850, 320, "span.png")
span2 = Sprite(520, 140, "span2.png")
span3 = Sprite(520, 140, "span3.png")

indus_start = Sprite(400, 250, "indus2.png")
indus_start1 = Sprite(400, 250, "indus.png")
# Индус улыбка
indus = (520, 250, "indus1.png")
# Индус закрытые глаза
indus1 = Sprite(520, 250, "indus2.png")
# Индус грусть
indus2 = Sprite(520, 140, "indus4.png")
indus2_g = Sprite(515, 250, "indus4.png")
# Индус злой
indus3 = Sprite(520, 250, "indus.png")

# в игре
indus_g = Sprite(480, 250, "indus2.png")

# карточки для игры
paper_ = Fon(300, 140, "paper6.png")
scissors_ = Fon(300, 140, "scissors.png")
stone_ = Fon(300, 140, "stone.png")
paper_1 = Fon(740, 140, "paper6.png")
scissors_1 = Fon(740, 140, "scissors.png")
stone_1 = Fon(740, 140, "stone.png")

# фоны
# начальный экран
bg1 = Fon(0, 0, "bg1.png")
# место проведения турнира
bg2 = Fon(0, 0, "bg2.png")
# здание
bg3 = Fon(0, 0, "bg3.jpg")
# поезд
bg4 = Fon(0, 0, "bg4.png")
# черный экран
bg5 = Fon(0, 0, "black.png")
# станция
bg6 = Fon(0, 0, "bg6.png")
# улица с трибунами
bg7 = Fon(0, 0, "bg5.png")
# белый экран
white_ = Fon(0, 0, "white.png")

# Поражение в конце
end_ = Fon(0, 0, "end.png")
# Победа в конце
end1_ = Fon(0, 0, "end1.png")

# турнирная сетка
grid1 = Fon(50, 125, "grid1.png")

grid2 = Fon(50, 125, "grid2.png")
grid3 = Fon(50, 125, "grid3.png")


class Menu:
    # Покрытие False по-умолчанию
    hovered = False

    # Инициализация строк меню
    def __init__(self, text, pos):
        self.text = text
        self.pos = pos
        self.set_rect()
        self.draw()

    # Рисование и рендер
    def draw(self):
        self.set_rend()
        screen.blit(self.rend, self.rect)

    # Сам рендер
    def set_rend(self):
        self.rend = menu_font.render(self.text, True, self.get_color())

    # Указание цветов (Покрытый\Не покрытый)
    def get_color(self):
        if self.hovered:
            return (red)
        else:
            return (green_dark)

    # Рендер углов
    def set_rect(self):
        self.set_rend()
        self.rect = self.rend.get_rect()
        self.rect.topleft = self.pos


def helps():
    screen.blit(hl, (0, 0), pygame.FULLSCREEN)
    hlp = True
    while hlp:  # s   x   y
        # printText("Hello World", "DejaVuSans.ttf", 30, 10, 10, red)
        printText("Управление Игрой", "DejaVuSans.ttf", 30, 300, 10, yellow)
        printText("Для продвижения вперед, нажмите пробел или клавишу \"Enter\".", "DejaVuSans.ttf", 30, 140, 30,
                  yellow)
        printText("Для выбора, воспользуйтесь мышью.", "DejaVuSans.ttf", 30, 140, 60, yellow)
        ###
        pygame.display.flip()
        for event in pygame.event.get():
            if event.type == pygame.MOUSEBUTTONDOWN:
                # click.play()
                hlp = False
                mmenu()
            elif event.type == pygame.KEYDOWN:
                # click.play()
                hlp = False
                mmenu()


# Главное Меню
def mmenu():
    # Пункты меню
    menus = [Menu("НАЧАТЬ ИГРУ", (500, 355)),
             Menu("ПОМОЩЬ", (500, 405)),
             Menu("АВТОРЫ", (500, 455)),
             Menu("ВЫХОД", (500, 505))]
    begin = True
    screen.blit(mm, (0, 0))
    # Рабочий цикл
    while begin:
        pygame.event.pump()
        # Проверка пунктов меню
        for menu in menus:
            if menu.rect.collidepoint(pygame.mouse.get_pos()):
                menu.hovered = True
            else:
                menu.hovered = False
            menu.draw()
        pygame.display.flip()
        for event in pygame.event.get():
            if event.type == pygame.MOUSEBUTTONDOWN:  # and event.button == 1: ## Небольшая правка
                for menu in menus:
                    if menu.hovered and menu.text == "НАЧАТЬ ИГРУ":
                        print("НОВАЯ ИГРА")
                        # click.play()
                        novel()
                    elif menu.hovered and menu.text == "ПОМОЩЬ":
                        print("ПОМОЩЬ")
                        # click.play()
                        helps()
                    elif menu.hovered and menu.text == "АВТОРЫ":
                        print("АВТОРЫ")
                        # click.play()
                        authors()
                    elif menu.hovered and menu.text == "ВЫХОД":
                        begin = False
                        # click.play()
                        pygame.quit()


def helps():
    screen.blit(hl, (0, 0))
    hlp = True
    while hlp:  # s   x   y
        # printText("Hello World", "DejaVuSans.ttf", 30, 10, 10, red)
        printText("Управление Игрой", "DejaVuSans.ttf", 30, 300, 10, yellow)
        printText("Для продвижения вперед, нажмите пробел или клавишу \"Enter\".", "DejaVuSans.ttf", 30, 140, 30,
                  yellow)
        printText("Для выбора, воспользуйтесь мышью.", "DejaVuSans.ttf", 30, 140, 60, yellow)

        pygame.display.flip()
        for event in pygame.event.get():
            if event.type == pygame.MOUSEBUTTONDOWN:
                # click.play()
                hlp = False
                mmenu()
            elif event.type == pygame.KEYDOWN:
                # click.play()
                hlp = False
                mmenu()


def authors():
    screen.blit(ab, (0, 0))
    aut = True
    while aut:  # s   x   y
        # printText("Hello World", "DejaVuSans.ttf", 30, 10, 10, red)
        printText(f"Над проектом работали: Гафаров Аяз, Русаков Илья", "DejaVuSans.ttf", 30, 390, 10, yellow)
        printText(f"Автор сценария: Гафаров Аяз", "DejaVuSans.ttf", 30, 430, 35, yellow)
        pygame.display.flip()
        for event in pygame.event.get():
            if event.type == pygame.MOUSEBUTTONDOWN:
                aut = False
                # click.play()
                mmenu()
            elif event.type == pygame.KEYDOWN:
                aut = False
                # click.play()
                mmenu()


def novel():
    font = pygame.font.Font(None, 72)
    bg1.back()
    menus = [Menu("Камень", (300, 255)),
             Menu("Ножницы", (300, 305)),
             Menu("Бумага", (300, 355))]
    while b == True:
        pygame.event.pump()
        for menu in menus:
            if menu.rect.collidepoint(pygame.mouse.get_pos()):
                menu.hovered = True
            else:
                menu.hovered = False
            menu.draw()
        pygame.display.flip()
        for event in pygame.event.get():
            if event.type == pygame.MOUSEBUTTONDOWN:
                for menu in menus:
                    if menu.hovered and menu.text == "Ножницы":
                        # click.play()
                        scissors()
                    elif menu.hovered and menu.text == "Камень":
                        # click.play()
                        stone()
                    elif menu.hovered and menu.text == "Бумага":
                        # click.play()
                        paper()

    unNoDialog = Dialog(screen)
    unNoDialog.message = ("Эх... порой удача так много решает, что может кординально поменять всю твою жизнь....",)

    unNoDialog.show = True
    unNoDialog.sndNext()
    unNoDialog.message = ("Я 17 летний парень из провинци, который случайно в своем городе наткнулся на турнир"
                          " по ""камень ножницы бумага.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    unNoDialog.message = ("Победив в своем городе, я отправился выступать за свой округю",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    unNoDialog.message = ("Где так же одержал"
                          " сухую победу над всеми оппонентами.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    unNoDialog.message = ("Затем и чемпионат России...",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    unNoDialog.message = ("И вот сейчас... я еду в Москву, на чемпионат Мира...",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    unNoDialog.message = ("Хе-хе-хе... как же после этого не назвать меня везунчиком?.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    unNoDialog.message = ("Но порой меня охватывает странное чувство будто "
                          "сама судьба направляла меня к этому момету.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    unNoDialog.message = ("Надеюсь я смогу одолеть хотя бы парочку противников....",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    unNoDialog.message = ("(кто то толкает в бок главного героя).",)
    bg4.back()
    unNoDialog.show = True
    unNoDialog.sndNext()
    unNoDialog.message = ("-???- = Эй, вставай, мы скоро подъедем!.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    unNoDialog.message = ("-мысли- = Открыв глаза, перед моим взором востал силуэт милой девченки.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    Anya_start.pers()
    unNoDialog.sndNext()
    unNoDialog.message = ("-мысли- = Это была моя подруга детства, Аня.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    unNoDialog.message = ("-мысли- = С самого начала этого пути она была со мной и поддерживала меня/",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    unNoDialog.message = ("-мысли- = Так же она хороша в психологии и часто давала мне советы,"
                          " благодаря которым я одерживал победу.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    unNoDialog.message = ("-Серега- = Что, мы уже в Москве?.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    bg4.back()
    Anya.pers()
    unNoDialog.message = ("-Аня- = Конечно, ты проспал весь наш путь, небось всю ночь опять играл в свои игры....",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    unNoDialog.message = ("-мысли- = Так и есть, но эти слова будто затронули мою гордость.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    unNoDialog.message = ("-Серега- = С чего ты взяла?.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    bg4.back()
    Anya_h.pers()
    unNoDialog.message = ("-Аня- = Да на твоем лице все написано!.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    unNoDialog.message = ("-Аня- = хи-хи-хи.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    unNoDialog.message = ("-мысли- = Каждый раз когда я слышу ее милый смех,"
                          " он будто наполняет меня неким зарядом счастья.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    unNoDialog.message = ("-Серега- = Ладно, проехали...",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    unNoDialog.message = ("-Серега- = Скорее бы узнать кто мой первый соперник.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    bg4.back()
    Anya_d.pers()
    bg5.back()
    printText("Некоторе время спустя......", "DejaVuSans.ttf", 100, 150, 450, red)
    unNoDialog.message = ("-Аня- = Да уж... Пошли уже, наша станция.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    bg6.back()
    unNoDialog.message = ("-мысли- Мы потихоньку вышли с транспорта и направились в сторону место проведения турнира.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    bg5.back()
    unNoDialog.message = ("-мысли- Я был настолько в облаках, что не заметил как уже оказался в здании.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    bg3.back()
    unNoDialog.message = ("-мысли- Вся моя голова была забита мыслями о победе.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    unNoDialog.message = ("-мысли- Тут было много народа и сплошной шум... Бесит!.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    unNoDialog.message = ("На турнире России было примерно столько же, но даже там не было так шумно.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    Anya_start.pers()
    unNoDialog.message = ("-Серега- Аня, пошли посмотрим на сетку и быстрее пройдем на нашу площадку.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    unNoDialog.message = ("-Аня- согласна, не люблю этих СМИ.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    unNoDialog.message = ("Подойдя к стенду, мы увидели следующее",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    white_.back()
    grid1.back()
    unNoDialog.message = ("-мысли- Значит первая игра будет с Индией, в прошлом году она была на 3 месте..",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    unNoDialog.message = ("-мысли- Я потихоньку начал нервничать, пытаясь не показать это Ане, я промолвил.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    unNoDialog.message = ("-Серега- Могло быть и лучше.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    bg3.back()
    Anya.pers()
    unNoDialog.message = ("-Аня- Уже подсознательно сдался?.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    unNoDialog.message = ("-Серега- Нет конечно, просто как то не по себе....",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    unNoDialog.message = ("-Аня- Да ладно тебе, главное не паникуй и думай о победе!.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    unNoDialog.message = ("-Серега- Хорошо, пошли!",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    bg3.back()
    Anya_start.pers()
    unNoDialog.message = ("-Аня- Угу.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    bg2.back()
    unNoDialog.message = ("(Мы направились на нашу площадку, где меня уже ожидал оппонент и судья).",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    sudia.pers()
    indus_start.pers()
    unNoDialog.message = ("-судья- Обе стороны пришли, можете начинать первый раунд.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    bg2.back()
    sudia.pers()
    indus_start1.pers()
    unNoDialog.message = ("-индус- Явился всё-таки....",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    unNoDialog.message = ("-мысли- Хоть я его впервые вижу, мне кажется, он слишком высокого мнения о себе....",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    unNoDialog.message = ("-мысли- Его самоувереность бесит меня!.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    bg2.back()
    Anya_d.pers()
    unNoDialog.message = ("-Аня- Честно говоря, не нравится мне этот тип....",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    unNoDialog.message = ("-Серега- Соглашусь.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    bg2.back()
    indus2.pers()
    unNoDialog.message = ("-индус- ЧТО ВЫ ТАМ ШЕПЧЕТЕСЬ!!!.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    unNoDialog.message = ("-индус- Я НЕ ПОТЕРПЛЮ НАСМЕШЕК В МОЮ СТОРОНУ!!!.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    unNoDialog.message = ("-Серега- Извините, тактику просто обсуждали.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    bg2.back()
    indus_g.pers()
    unNoDialog.message = ("-индус- Что с вами поделать....",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    unNoDialog.message = ("-судья- НАЧИНАЕМ.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    unNoDialog.message = ("-Аня- Удачи тебе!.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    unNoDialog.message = ("-Серега- Угу, она мне явно понадобится.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    unNoDialog.message = ("-мысли- Я встал на против своего противника, достал карточки для игры и"
                          " в своей голове уже понял что буду ставить...",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    menus = [Menu("Камень", (300, 255)),
             Menu("Ножницы", (300, 305)),
             Menu("Бумага", (300, 355))]
    while b == True:
        pygame.event.pump()
        for menu in menus:
            if menu.rect.collidepoint(pygame.mouse.get_pos()):
                menu.hovered = True
            else:
                menu.hovered = False
            menu.draw()
        pygame.display.flip()
        for event in pygame.event.get():
            if event.type == pygame.MOUSEBUTTONDOWN:
                for menu in menus:
                    if menu.hovered and menu.text == "Ножницы":
                        # click.play()
                        scissors()
                    elif menu.hovered and menu.text == "Камень":
                        # click.play()
                        stone()
                    elif menu.hovered and menu.text == "Бумага":
                        # click.play()
                        paper()


# Бумага
def paper():
    font = pygame.font.Font(None, 72)
    bg2.back()
    indus_g.pers()
    unNoDialog = Dialog(screen)
    unNoDialog.message = ("-мысли- Моим ходом будет БУМАГА.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    paper_.back()
    unNoDialog.message = ("-мысли- Покажу этому высокомерному придурку свой гибкий разум.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    paper_.back()
    pc()


# Ножницы
def scissors():
    font = pygame.font.Font(None, 72)
    bg2.back()
    indus_g.pers()
    unNoDialog = Dialog(screen)
    unNoDialog.message = ("-мысли- Моим ходом будет НОЖНИЦЫ.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    scissors_.back()
    unNoDialog.message = ("-мысли- Покажу этому индусу как опасно со мной возиться.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    scissors_.back()
    scc()


# Камень
def stone():
    font = pygame.font.Font(None, 72)
    bg2.back()
    indus_g.pers()
    unNoDialog = Dialog(screen)
    unNoDialog.message = ("-мысли- Моим ходом будет КАМЕНЬ.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    stone_.back()
    unNoDialog.message = ("-мысли- Покажу этому зазнайке свой твердый и жесткий характер!!!.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    stone_.back()
    sc()


# продолжаем...
def scc():
    sps = ['камень', 'ножницы', 'бумага']
    a = random.choice(sps)
    if a == 'камень':
        stone_1.back()
        unNoDialog = Dialog(screen)
        unNoDialog.message = ("ЧЕЕЕРТ.",)
        unNoDialog.show = True
        unNoDialog.sndNext()
        unNoDialog.message = ("ОН ПОСТАВИЛ КАМЕНЬ.",)
        unNoDialog.show = True
        unNoDialog.sndNext()
        unNoDialog.message = ("Я ПРОИГРАЛ.",)
        unNoDialog.show = True
        unNoDialog.sndNext()
        end()

    elif a == 'ножницы':
        scissors_1.back()
        draw()

    elif a == 'бумага':
        bg2.back()
        indus2_g.pers()
        scissors_.back()
        paper_1.back()
        unNoDialog = Dialog(screen)
        unNoDialog.message = ("УРААА.",)
        unNoDialog.show = True
        unNoDialog.sndNext()
        unNoDialog.message = ("ОН ПОСТАВИЛ БУМАГУ.",)
        unNoDialog.show = True
        unNoDialog.sndNext()
        unNoDialog.message = ("ОН ПРОИГРАЛ.",)
        unNoDialog.show = True
        unNoDialog.sndNext()
        unNoDialog.message = ("Я смог одолеть его!!!.",)
        unNoDialog.show = True
        unNoDialog.sndNext()
        win()


def sc():
    sps = ['камень', 'ножницы', 'бумага']
    a = random.choice(sps)
    if a == 'камень':
        stone_1.back()
        draw()

    elif a == 'ножницы':
        bg2.back()
        indus2_g.pers()
        stone_.back()
        scissors_1.back()
        unNoDialog = Dialog(screen)
        unNoDialog.message = ("ПОВЕЗЛО.......",)
        unNoDialog.show = True
        unNoDialog.sndNext()
        unNoDialog.message = ("ОН ПОСТАВИЛ НОЖНИЦЫ.",)
        unNoDialog.show = True
        unNoDialog.sndNext()
        unNoDialog.message = ("Я ВЫЙГРАЛ.",)
        unNoDialog.show = True
        unNoDialog.sndNext()
        win()

    elif a == 'бумага':
        paper_1.back()
        unNoDialog = Dialog(screen)
        unNoDialog.message = ("ЧЕЕЕРТ.",)
        unNoDialog.show = True
        unNoDialog.sndNext()
        unNoDialog.message = ("ОН ПОСТАВИЛ БУМАГУ.",)
        unNoDialog.show = True
        unNoDialog.sndNext()
        unNoDialog.message = ("Я ПРОИГРАЛ.",)
        unNoDialog.show = True
        unNoDialog.sndNext()
        end()


def pc():
    sps = ['камень', 'ножницы', 'бумага']
    a = random.choice(sps)
    if a == 'камень':
        bg2.back()
        indus2_g.pers()
        paper_.back()
        stone_1.back()
        unNoDialog = Dialog(screen)
        unNoDialog.message = ("УРААА.",)
        unNoDialog.show = True
        unNoDialog.sndNext()
        unNoDialog.message = ("ОН ПОСТАВИЛ КАМЕНЬ.",)
        unNoDialog.show = True
        unNoDialog.sndNext()
        unNoDialog.message = ("Я ВЫЙГРАЛ, ЭТО БЫЛО ДОВОЛЬНО ЛЕГКО.",)
        unNoDialog.show = True
        unNoDialog.sndNext()
        win()

    elif a == 'ножницы':
        scissors_1.back()
        unNoDialog = Dialog(screen)
        unNoDialog.message = ("ЧЕЕЕРТ.",)
        unNoDialog.show = True
        unNoDialog.sndNext()
        unNoDialog.message = ("ОН ПОСТАВИЛ НОЖНИЦЫ.",)
        unNoDialog.show = True
        unNoDialog.sndNext()
        unNoDialog.message = ("Я ПРОИГРАЛ!!!.",)
        unNoDialog.show = True
        unNoDialog.sndNext()
        end()

    elif a == 'бумага':
        paper_1.back()
        draw()


def draw():
    unNoDialog = Dialog(screen)
    unNoDialog.message = ("ЭТО НИЧЬЯ.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    unNoDialog = Dialog(screen)
    unNoDialog.message = ("А ЗНАЧИТ ПРИДЕТСЯ ВЫБРАТЬ ЕЩЕ РАЗ.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    bg2.back()
    indus_g.pers()


def scissors2():
    unNoDialog = Dialog(screen)
    unNoDialog.message = ("-мысли- Моим ходом будет НОЖНИЦЫ!",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    scissors_.back()


def paper2():
    font = pygame.font.Font(None, 72)
    unNoDialog = Dialog(screen)
    unNoDialog.message = ("-мысли- Моим ходом будет БУМАГА.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    paper_.back()


def stone2():
    font = pygame.font.Font(None, 72)
    unNoDialog = Dialog(screen)
    unNoDialog.message = ("-мысли- Моим ходом будет КАМЕНЬ.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    stone_.back()


# и снова продолжение.....
def continue_():
    bg2.back()
    indus2_g.pers()
    unNoDialog = Dialog(screen)
    unNoDialog.message = ("-Индус- КАК ТАК?! КАК ТЫ СУМЕЛ ОДОЛЕТЬ МЕНЯ?!.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    bg2.back()
    indus2.pers()
    continue1()


def continue1():
    bg5.back()
    unNoDialog = Dialog(screen)
    unNoDialog.message = ("-Серега- Спасибо за игру, дружище!!!.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    unNoDialog.message = ("-Индус- ЧТОБ ТЕБЯ!.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    bg2.back()
    Anya.pers()
    unNoDialog.message = ("-Аня- УРА! Я так рада за тебя!.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    bg2.back()
    Anya_start.pers()
    unNoDialog.message = ("Спасибо, Аня! Без тебя бы я не справился!.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    unNoDialog.message = ("-мысли- В момент я подумал, что я могу свернуть горы, "
                          "но мои мысли остановил голос судьи...",)
    unNoDialog.show = True
    bg2.back()
    sudia.pers()
    unNoDialog.sndNext()
    unNoDialog.message = ("-судья- Поздравляю, вы проходите дальше к следующей игре!.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    unNoDialog.message = ("-Серега- хорошо.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    bg5.back()
    unNoDialog.message = ("-мысли- После победы над индусом, долго радоваться нам не пришлось..",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    unNoDialog.message = ("-мысли- Выйдя обратно с арены, я посмотрел на турнирную сетку.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    white_.back()
    grid2.back()
    unNoDialog.message = ("-Серега- Значит мой следующий соперник это Испанец.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    Anya.pers()
    unNoDialog.message = ("-Аня- В прошлом году, Испания особых успехов не добилась.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    unNoDialog.message = ("-Аня- Но говорят, что в этом, она победила бывшего финалиста....",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    unNoDialog.message = ("-Аня- Она победила Китай..",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    bg5.back()
    unNoDialog.message = ("-серега- эх.... блин... как то страшно чтоль...",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    unNoDialog.message = ("-Аня- Да не переживай, дурачек, Индию ты тоже боялся, а вон как себя проявил....",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    unNoDialog.message = ("-мысли- Она права, рано отпускать руки....",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    screen.fill('black')
    printText("В этот момент я почувствовал легкий толчок в спину", "DejaVuSans.ttf", 85, 40, 500, white)
    unNoDialog.message = ("-???- Простите, я не специально!.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    unNoDialog.message = ("Повернувшись я увидел светловолосого блондина, высокого роста.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    printText("Его голубые глаза были уставлены на меня", "DejaVuSans.ttf", 100, 60, 500, white)
    unNoDialog.message = ("",)
    bg3.back()
    unNoDialog.message = ("-???- О, вы же представитель России!.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    unNoDialog.message = ("-???- Примите мои поздравления!.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    unNoDialog.message = ("-Серега- Спасибо огромное!.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    unNoDialog.message = ("-Аня- Слушайте....",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    unNoDialog.message = ("-Аня- Ваше лицо мне кажется очень знакомым....",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    unNoDialog.message = ("-???- Да ну что вы, я впервые вас вижу.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    printText("После недолгой паузы, незнакомец обратился ко мне", "DejaVuSans.ttf", 100, 70, 500, white)
    bg3.back()
    unNoDialog.message = ("-???- Разрешите мне взглянуть на таблицу?.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    unNoDialog.message = ("-Серега- Ой, простите, прошу.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    printText("Я отошел в сторону, чтоб дать ему посмотреть на сетку", "DejaVuSans.ttf", 100, 70, 500, white)
    bg3.back()
    unNoDialog.message = ("-???- Так вот значит как....",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    unNoDialog.message = ("-???- Ну, мне пора!.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    unNoDialog.message = ("-Серега- Удачи вам!.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    unNoDialog.message = ("-???- Спасибо! Скоро увидимся!.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    printText("После этих слов, незнакомец ушел, оставив меня в недоумении", "DejaVuSans.ttf", 100, 70, 500, white)
    unNoDialog.message = ("-Серега- Что значит скоро увидимся?.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    unNoDialog.message = ("-Аня- Не морочь себе голову.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    unNoDialog.message = ("-Серега- Да, пожалуй так и сделаю.....",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    printText("До игры оставалось 30 минут, и я решил вздремнуть", "DejaVuSans.ttf", 100, 70, 500, white)
    screen.fill('black')
    printText("Закрыв глаза я начал думать о том, что будет после победы", "DejaVuSans.ttf", 100, 70, 500, white)
    screen.fill('black')
    printText("На самом деле, я очень давно хотел признаться Ане...", "DejaVuSans.ttf", 100, 70, 500, white)
    screen.fill('black')
    printText("Да, все это время я был в нее влюблен...", "DejaVuSans.ttf", 100, 70, 500, white)
    screen.fill('black')
    printText("Да, все это время я был в нее влюблен...", "DejaVuSans.ttf", 100, 70, 500, white)
    screen.fill('black')
    printText("А может признаться ей если смогу всех победить?", "DejaVuSans.ttf", 100, 70, 500, white)
    screen.fill('black')
    printText("Да не, думаю это глупо...", "DejaVuSans.ttf", 100, 70, 500, white)
    screen.fill('black')
    printText("Хотя...", "DejaVuSans.ttf", 100, 70, 500, white)
    screen.fill('black')
    printText("(кто то трясет главного героя)", "DejaVuSans.ttf", 100, 70, 500, white)
    screen.fill('black')
    printText("Открыв глаза я опять увидел её", "DejaVuSans.ttf", 100, 70, 500, white)
    screen.fill('black')
    bg3.back()
    unNoDialog.message = ("-Аня- Ну что, пошли!.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    unNoDialog.message = ("-Серега- Конечно!.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    printText("После этих слов, ты оправились на назначенное место...", "DejaVuSans.ttf", 100, 70, 500, white)
    screen.fill('black')
    printText("Придя на место, я увидел только судью", "DejaVuSans.ttf", 100, 70, 500, white)
    screen.fill('black')
    bg3.back()
    unNoDialog.message = ("-Судья- Аппонент еще не пришел, если он не явится следующие 5 минут....",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    unNoDialog.message = ("-Судья- То придется засчитать вам техническую победу.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    unNoDialog.message = ("-Аня- Будет круто! Хе-хе-хе..",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    unNoDialog.message = ("-Серега- Тогда я точно попаду в финал!.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    unNoDialog.message = ("-Мысли- Я буду очень рад такому раскладу событий....",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    pygame.display.flip()


# победа
def win():
    screen.fill((0, 0, 0))
    continue_()


# конец
def end():
    bg5.back()
    b = False
    screen.fill((0, 0, 0))
    printText("К сожалению, в этой игре вы проиграли", "DejaVuSans.ttf", 100, 120, 450, red)
    printText("Вы всегда можете начать эту игру с начала", "DejaVuSans.ttf", 100, 120, 450, red)
    printText("Мы очень стрались", "DejaVuSans.ttf", 100, 120, 450, red)
    printText("Надеемся вам понравилась", "DejaVuSans.ttf", 100, 120, 450, red)
    end_.back()
    pygame.display.flip()
    for event in pygame.event.get():
        if event.type == pygame.MOUSEBUTTONDOWN:
            mmenu()
        elif event.type == pygame.KEYDOWN:
            mmenu()


def end1():
    screen.fill((0, 0, 0))
    printText("я выйграл...", "DejaVuSans.ttf", 35, 80, 280, red)
    printText("Я ПОБЕДИЛ,", "DejaVuSans.ttf", 35, 80, 280, red)
    printText("ИГРА ОКОНЧЕНА", "DejaVuSans.ttf", 35, 80, 310, red)
    printText("СПАСИБО", "DejaVuSans.ttf", 35, 80, 340, red)
    pygame.display.flip()
    for event in pygame.event.get():
        if event.type == pygame.MOUSEBUTTONDOWN:
            mmenu()
        elif event.type == pygame.KEYDOWN:
            mmenu()


def main_loose():
    screen.fill('black')
    printText("СПАСИБО ЗА ИГРУ", "DejaVuSans.ttf", 35, 80, 280, red)
    printText("МЫ ОЧЕНЬ НАДЕЕМСЯ ЧТО ВАМ ПОНРАВИЛОСЬ", "DejaVuSans.ttf", 35, 80, 280, red)
    printText("УДАЧИ И ПОКА", "DejaVuSans.ttf", 35, 80, 280, red)
    end_.back()
    menus = [Menu("НАЧАТЬ ИГРУ", (500, 355)),
             Menu("ПОМОЩЬ", (500, 405)),
             Menu("АВТОРЫ", (500, 455)),
             Menu("ВЫХОД", (500, 505))]
    begin = True
    screen.blit(mm, (0, 0))
    # Рабочий цикл
    while begin:
        pygame.event.pump()
        # Проверка пунктов меню
        for menu in menus:
            if menu.rect.collidepoint(pygame.mouse.get_pos()):
                menu.hovered = True
            else:
                menu.hovered = False
            menu.draw()
        pygame.display.flip()
        for event in pygame.event.get():
            if event.type == pygame.MOUSEBUTTONDOWN:  # and event.button == 1: ## Небольшая правка
                for menu in menus:
                    if menu.hovered and menu.text == "НАЧАТЬ ИГРУ":
                        print("НОВАЯ ИГРА")
                        # click.play()
                        novel()
                    elif menu.hovered and menu.text == "ПОМОЩЬ":
                        print("ПОМОЩЬ")
                        # click.play()
                        helps()
                    elif menu.hovered and menu.text == "АВТОРЫ":
                        print("АВТОРЫ")
                        # click.play()
                        authors()
                    elif menu.hovered and menu.text == "ВЫХОД":
                        begin = False
                        # click.play()
                        pygame.quit()


# проигрыш
def loose():
    unNoDialog = Dialog(screen)
    unNoDialog.message = ("-мысли- увидев довольное лицо своего врага, я закрыл глаза....",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    unNoDialog.message = ("-мысли- неужели на этом все закончиться, неужели я больше ничего не смогу?.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    unNoDialog.message = ("-мысли- уйдя в себя... я уже ничего не слышал....",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    screen.fill('black')
    main_loose()


def main():
    # pygame.mixer.music.play(-1)
    mmenu()
    begin = True
    keys = pygame.key.get_pressed()
    while begin:
        for event in pygame.event.get():
            if event.type == pygame.KEYDOWN:
                if event.key == keys[pygame.K_ESCAPE]:
                    begin = False
                    pygame.quit()
                    break

            if event.type == pygame.QUIT:
                begin = False
                pygame.quit()
                break


# Запуск программы
if __name__ == "__main__":
    main()
