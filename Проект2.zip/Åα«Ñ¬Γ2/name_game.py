import os
import random

import pygame

from dialog import Dialog

# инициализация
pygame.mixer.pre_init(44100, -16, 2, 2048)
pygame.init()

# цвета
red = (255, 0, 0)
green = (81, 220, 55)
blue = (0, 0, 255)
black = (0, 0, 0)
yellow = (255, 255, 0)
white = (255, 255, 255)

# экран
ico = pygame.image.load(('icon.png'))
icon = pygame.transform.scale(ico, (32, 32))
pygame.display.set_icon(icon)
screen = pygame.display.set_mode((800, 900), pygame.FULLSCREEN)
pygame.display.set_caption('камень ножницы бумага')


# текст справки и помощи
def printText(txtText, Textfont, Textsize, Textx, Texty, Textcolor):
    myfont = pygame.font.SysFont(Textfont, Textsize)
    label = myfont.render(txtText, 0, Textcolor)
    screen.blit(label, (Textx, Texty))


# фоны
mm = pygame.image.load(os.path.join("image", "play.png"))
hl = pygame.image.load(os.path.join("image", "play.png"))
ab = pygame.image.load(os.path.join("image", "play.png"))

# Шрифт
menu_font = pygame.font.Font("font\DejaVuSans.ttf", 30)
# Музыка
pygame.mixer.music.load(os.path.join('audio', 'theme.ogg'))
click = pygame.mixer.Sound(os.path.join('audio', 'click.wav'))


class Sprite:
    def __init__(self, xpos, ypos, filename):
        self.x = xpos
        self.y = ypos
        self.bitmap = pygame.image.load(os.path.join("image\persons", filename))

    def pers(self):
        screen.blit(self.bitmap, (self.x, self.y))


class Fon:
    def __init__(self, xpos, ypos, filename):
        self.x = xpos
        self.y = ypos
        self.bitmap = pygame.image.load(os.path.join("image", "backgrounds", filename))

    def back(self):
        screen.blit(self.bitmap, (self.x, self.y))


sudia = Sprite(520, 200, "sudia.png")

Anya_start = Sprite(520, 140, "Anya_start.png")
Anya = Sprite(900, 290, "Anya_.png")
Anya_f = Sprite(520, 140, "Anya_final.png")
Anya_h = Sprite(520, 140, "Anya_happy.png")

span = Sprite(520, 140, "span.png")
span2 = Sprite(520, 140, "span2.png")
span3 = Sprite(520, 140, "span3.png")

# Индус улыбка
indus = Sprite(920, 300, "indus1.png")
# Индус закрытые глаза
indus1 = Sprite(520, 250, "indus2.png")
# Индус грусть
indus2 = Sprite(520, 140, "indus4.png")
# Индус злой
indus3 = Sprite(520, 250, "indus.png")

# карточки для игры
paper_ = Fon(520, 140, "paper.png")
scissors_ = Fon(520, 140, "scissors.png")
stone_ = Fon(520, 140, "stone.png")

# фоны
# начальный экран
bg1 = Fon(0, 0, "bg1.png")
# место проведения турнира
bg2 = Fon(0, 0, "bg2.png")
# поезд
bg4 = Fon(0, 0, "bg4.png")
# черный экран
bg12 = Fon(0, 0, "bg12.png")
# станция
bg45 = Fon(0, 0, "bg45.png")
# улица с трибунами
bg15 = Fon(0, 0, "bg15.png")
# белый экран
white_ = Fon(0, 0, "white.png")

# турнирная сетка
grid1 = Fon(50, 125, "grid1.png")
grid2 = Fon(50, 125, "grid2.png")
grid3 = Fon(50, 125, "grid3.png")
# Фоны концовок
end_ = Fon(0, 0, "end.png")
end1_ = Fon(0, 0, "end1.png")


class Menu:
    # Покрытие False по-умолчанию
    hovered = False

    # Инициализация строк меню
    def __init__(self, text, pos):
        self.text = text
        self.pos = pos
        self.set_rect()
        self.draw()

    # Рисование и рендер
    def draw(self):
        self.set_rend()
        screen.blit(self.rend, self.rect)

    # Сам рендер
    def set_rend(self):
        self.rend = menu_font.render(self.text, True, self.get_color())

    # Указание цветов (Покрытый\Не покрытый)
    def get_color(self):
        if self.hovered:
            return (red)
        else:
            return (yellow)

    # Рендер углов
    def set_rect(self):
        self.set_rend()
        self.rect = self.rend.get_rect()
        self.rect.topleft = self.pos


def helps():
    screen.blit(hl, (0, 0), pygame.FULLSCREEN)
    hlp = True
    while hlp:  # s   x   y
        # printText("Hello World", "DejaVuSans.ttf", 30, 10, 10, red)
        printText("Управление Игрой", "DejaVuSans.ttf", 30, 300, 10, yellow)
        printText("Для продвижения вперед, нажмите пробел или клавишу \"Enter\".", "DejaVuSans.ttf", 30, 140, 30,
                  yellow)
        printText("Для выбора, воспользуйтесь мышью.", "DejaVuSans.ttf", 30, 140, 60, yellow)
        ###
        pygame.display.flip()
        for event in pygame.event.get():
            if event.type == pygame.MOUSEBUTTONDOWN:
                click.play()
                hlp = False
                mmenu()
            elif event.type == pygame.KEYDOWN:
                click.play()
                hlp = False
                mmenu()


# Главное Меню
def mmenu():
    # Пункты меню
    menus = [Menu("НАЧАТЬ ИГРУ", (500, 355)),
             Menu("ПОМОЩЬ", (500, 405)),
             Menu("АВТОРЫ", (500, 455)),
             Menu("ВЫХОД", (500, 505))]
    begin = True
    screen.blit(mm, (0, 0))
    # Рабочий цикл
    while begin:
        pygame.event.pump()
        # Проверка пунктов меню
        for menu in menus:
            if menu.rect.collidepoint(pygame.mouse.get_pos()):
                menu.hovered = True
            else:
                menu.hovered = False
            menu.draw()
        pygame.display.flip()
        for event in pygame.event.get():
            if event.type == pygame.MOUSEBUTTONDOWN:  # and event.button == 1: ## Небольшая правка
                for menu in menus:
                    if menu.hovered and menu.text == "НАЧАТЬ ИГРУ":
                        print("НОВАЯ ИГРА")
                        click.play()
                        novel()
                    elif menu.hovered and menu.text == "ПОМОЩЬ":
                        print("ПОМОЩЬ")
                        click.play()
                        helps()
                    elif menu.hovered and menu.text == "АВТОРЫ":
                        print("АВТОРЫ")
                        click.play()
                        authors()
                    elif menu.hovered and menu.text == "ВЫХОД":
                        begin = False
                        click.play()
                        pygame.quit()


def helps():
    screen.blit(hl, (0, 0))
    hlp = True
    while hlp:  # s   x   y
        # printText("Hello World", "DejaVuSans.ttf", 30, 10, 10, red)
        printText("Управление Игрой", "DejaVuSans.ttf", 30, 300, 10, yellow)
        printText("Для продвижения вперед, нажмите пробел или клавишу \"Enter\".", "DejaVuSans.ttf", 30, 140, 30,
                  yellow)
        printText("Для выбора, воспользуйтесь мышью.", "DejaVuSans.ttf", 30, 140, 60, yellow)

        pygame.display.flip()
        for event in pygame.event.get():
            if event.type == pygame.MOUSEBUTTONDOWN:
                click.play()
                hlp = False
                mmenu()
            elif event.type == pygame.KEYDOWN:
                click.play()
                hlp = False
                mmenu()


def authors():
    screen.blit(ab, (0, 0))
    aut = True
    while aut:  # s   x   y
        # printText("Hello World", "DejaVuSans.ttf", 30, 10, 10, red)
        printText(f"Над проектом работали: Гафаров Аяз, Русаков Илья", "DejaVuSans.ttf", 30, 390, 10, yellow)
        printText(f"Автор сценария: Гафаров Аяз", "DejaVuSans.ttf", 30, 430, 35, yellow)
        pygame.display.flip()
        for event in pygame.event.get():
            if event.type == pygame.MOUSEBUTTONDOWN:
                aut = False
                click.play()
                mmenu()
            elif event.type == pygame.KEYDOWN:
                aut = False
                click.play()
                mmenu()


def novel():
    font = pygame.font.Font(None, 72)
    bg1.back()
    unNoDialog = Dialog(screen)
    unNoDialog.message = ("Эх... порой удача так много решает, что может кординально поменять всю твою жизнь....",)

    unNoDialog.show = True
    unNoDialog.sndNext()
    # menus = [Menu("Камень", (300, 255)),
    # Menu("Ножницы", (300, 305)),
    # Menu("Бумага", (300, 355))]
    # while True:
    #  pygame.event.pump()
    #  for menu in menus:
    #      if menu.rect.collidepoint(pygame.mouse.get_pos()):
    #         menu.hovered = True
    #    else:
    #        menu.hovered = False
    #    menu.draw()
    #  pygame.display.flip()
    # for event in pygame.event.get():
    #     if event.type == pygame.MOUSEBUTTONDOWN:
    #    for menu in menus:
    #   if menu.hovered and menu.text == "Ножницы":
    #    click.play()
    #   scissors()
    #  elif menu.hovered and menu.text == "Камень":
    #       click.play()
    #       stone()
    #  elif menu.hovered and menu.text == "Бумага":
    #     click.play()
    #       paper()
    unNoDialog.message = ("Я 17 летний парень из провинци, который случайно в своем городе наткнулся на турнир"
                          " по ""камень ножницы бумага.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    unNoDialog.message = ("Победив в своем городе, я отправился выступать за свой округю",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    unNoDialog.message = ("Где так же одержал"
                          " сухую победу над всеми оппонентами.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    unNoDialog.message = ("Затем и чемпионат России...",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    unNoDialog.message = ("И вот сейчас... я еду в Москву, на чемпионат Мира...",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    unNoDialog.message = ("Хе-хе-хе... как же после этого не назвать меня везунчиком?.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    unNoDialog.message = ("Но порой меня охватывает странное чувство будто "
                          "сама судьба направляла меня к этому момету.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    unNoDialog.message = ("Надеюсь я смогу одолеть хотя бы парочку противников....",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    unNoDialog.message = ("(кто то толкает в бок главного героя).",)
    bg4.back()
    unNoDialog.show = True
    unNoDialog.sndNext()
    unNoDialog.message = ("-???- = Эй, вставай, мы скоро подъедем!.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    unNoDialog.message = ("-мысли- = Открыв глаза, перед моим взором востал силуэт милой девченки.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    Anya_start.pers()
    unNoDialog.sndNext()
    unNoDialog.message = ("-мысли- = Это была моя подруга детства, Аня.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    unNoDialog.message = ("-мысли- = С самого начала этого пути она была со мной и поддерживала меня/",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    unNoDialog.message = ("-мысли- = Так же она хороша в психологии и часто давала мне советы,"
                          " благодаря которым я одерживал победу.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    unNoDialog.message = ("-Серега- = Что, мы уже в Москве?.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    unNoDialog.message = ("-Аня- = Конечно, ты проспал весь наш путь, небось всю ночь опять играл в свои игры....",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    unNoDialog.message = ("-мысли- = Так и есть, но эти слова будто затронули мою гордость.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    unNoDialog.message = ("-Серега- = С чего ты взяла?.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    unNoDialog.message = ("-Аня- = Да на твоем лице все написано!.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    unNoDialog.message = ("-Аня- = хи-хи-хи.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    unNoDialog.message = ("-мысли- = Каждый раз когда я слышу ее милый смех,"
                          " он будто наполняет меня неким зарядом счастья.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    unNoDialog.message = ("-Серега- = Ладно, проехали...",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    unNoDialog.message = ("-Серега- = Скорее бы узнать кто мой первый соперник.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    unNoDialog.message = ("-Аня- = Да уж... Пошли уже, наша станция.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    bg45.back()
    unNoDialog.message = ("-мысли- Мы потихоньку вышли с транспорта и направились в сторону место проведения турнира.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    bg15.back()
    unNoDialog.message = ("-мысли- Я был настолько в облаках, что не заметил как уже окозался в здании.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    bg2.back()
    unNoDialog.message = ("-мысли- Вся моя голова была забита мыслями о победе.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    unNoDialog.message = ("-мысли- Тут было много народа и сплошной шум... Бесит!.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    unNoDialog.message = ("На турнире России было примерно столько же, но даже там не было так шумно.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    unNoDialog.message = ("-Серега- Аня, пошли посмотрим на сетку и быстрее пройдем на нашу площадку.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    unNoDialog.message = ("-Аня- согласна, не люблю этих СМИ.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    unNoDialog.message = ("-мысли- турнирная сетка выглядила так.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    white_.back()
    grid1.back()
    unNoDialog.message = ("-мысли- Значит первая игра будет с Индией, в прошлом году она была на 3 месте..",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    unNoDialog.message = ("-мысли- Я потихоньку начал нервничать, пытаясь не показать это Ане я промолвил.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    unNoDialog.message = ("-Серега- Могло быть и лучше.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    unNoDialog.message = ("-Аня- Уже подсознательно сдался?.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    unNoDialog.message = ("-Аня- Хе-хе-хе.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    unNoDialog.message = ("-Серега- Нет конечно, просто как то не по себе....",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    unNoDialog.message = ("-Аня- Да ладно тебе, главное не паникуй и думай о победе!.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    unNoDialog.message = ("-Серега- Хорошо, пошли!",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    unNoDialog.message = ("-Аня- Угу.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    unNoDialog.message = ("(Мы направились на нашу площадку, где меня уже ожидал оппонент и судья).",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    sudia.pers()
    indus.pers()
    unNoDialog.message = ("-судья- Обе стороны пришли, можете начинать первый раунд.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    unNoDialog.message = ("-индус- Явился всё-таки....",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    unNoDialog.message = ("-мысли- Хоть я его впервые вижу, мне кажется, он слишком высокого мнения о себе....",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    unNoDialog.message = ("-мысли- Его самоувереность бесит меня!.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    unNoDialog.message = ("-Аня- Честно говоря, не нравится мне этот тип....",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    unNoDialog.message = ("-Серега- Соглашусь.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    bg2.back()
    indus3.pers()
    unNoDialog.message = ("-индус- ЧТО ВЫ ТАМ ШЕПЧЕТЕСЬ!!!.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    unNoDialog.message = ("-индус- Я НЕ ПОТЕРПЛЮ НАСМЕШЕК В МОЮ СТОРОНУ!!!.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    unNoDialog.message = ("-Серега- Извините, тактику просто обсуждали.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    bg2.back()
    indus1.pers()
    unNoDialog.message = ("-индус- Что с вами поделать....",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    unNoDialog.message = ("-судья- НАЧИНАЕМ.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    unNoDialog.message = ("-Аня- Удачи тебе!.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    unNoDialog.message = ("-Серега- Угу, она мне явно понадобится.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    unNoDialog.message = ("-мысли- Я встал на против своего противника, достал карточки для игры и"
                          " в своей голове уже понял что буду ставить...",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    menus = [Menu("Камень", (300, 255)),
             Menu("Ножницы", (300, 305)),
             Menu("Бумага", (300, 355))]
    while True:
        pygame.event.pump()
        for menu in menus:
            if menu.rect.collidepoint(pygame.mouse.get_pos()):
                menu.hovered = True
            else:
                menu.hovered = False
            menu.draw()
        pygame.display.flip()
        for event in pygame.event.get():
            if event.type == pygame.MOUSEBUTTONDOWN:
                for menu in menus:
                    if menu.hovered and menu.text == "Ножницы":
                        click.play()
                        scissors()
                    elif menu.hovered and menu.text == "Камень":
                        click.play()
                        stone()
                    elif menu.hovered and menu.text == "Бумага":
                        click.play()
                        paper()


# Бумага
def paper():
    font = pygame.font.Font(None, 72)
    bg2.back()
    unNoDialog = Dialog(screen)
    unNoDialog.message = ("-мысли- Самым первым моим ходом будет БУМАГА.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    paper_.back()
    unNoDialog.message = ("-мысли- Покажу этому высокомерному придурку свой гибкий разум.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    paper_.back()
    pc()


# Ножницы
def scissors():
    font = pygame.font.Font(None, 72)
    bg2.back()
    unNoDialog = Dialog(screen)
    unNoDialog.message = ("-мысли- Самым первым моим ходом будет НОЖНИЦЫ.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    scissors_.back()
    unNoDialog.message = ("-мысли- Покажу этому индусу как опасно со мной возиться.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    scissors_.back()
    scc()


# Камень
def stone():
    font = pygame.font.Font(None, 72)
    bg2.back()
    unNoDialog = Dialog(screen)
    unNoDialog.message = ("-мысли- Самым первым моим ходом будет КАМЕНЬ.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    stone_.back()
    unNoDialog.message = ("-мысли- Покажу этому зазнайке свой твердый и жесткий характер!!!.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    stone_.back()
    sc()


# продолжаем...
def scc():
    sps = ['камень', 'ножницы', 'бумага']
    a = random.choice(sps)
    if a == 'камень':
        bg2.back()
        stone_.back()
        unNoDialog = Dialog(screen)
        unNoDialog.message = ("ЧЕЕЕРТ.",)
        unNoDialog.show = True
        unNoDialog.sndNext()
        unNoDialog.message = ("ОН ПОСТАВИЛ КАМЕНЬю",)
        unNoDialog.show = True
        unNoDialog.sndNext()
        unNoDialog.message = ("Я ПРОИГРАЛ",)
        unNoDialog.show = True
        unNoDialog.sndNext()
        loose()

    elif a == 'ножницы':
        bg2.back()
        scissors_.back()
        unNoDialog = Dialog(screen)
        unNoDialog.message = ("ЧЕЕЕРТ.",)
        unNoDialog.show = True
        unNoDialog.sndNext()
        unNoDialog.message = ("ОН ПОСТАВИЛ НОЖНИЦЫ.",)
        unNoDialog.show = True
        unNoDialog.sndNext()
        unNoDialog.message = ("ЭТО НИЧЬЯ!!!.",)
        unNoDialog.show = True
        unNoDialog.sndNext()
        draw()

    elif a == 'бумага':
        bg2.back()
        paper_.back()
        unNoDialog = Dialog(screen)
        unNoDialog.message = ("УРААА.",)
        unNoDialog.show = True
        unNoDialog.sndNext()
        unNoDialog.message = ("ОН ПОСТАВИЛ БУМАГУ.",)
        unNoDialog.show = True
        unNoDialog.sndNext()
        unNoDialog.message = ("ОН ПРОИГРАЛ.",)
        unNoDialog.show = True
        unNoDialog.sndNext()
        unNoDialog.message = ("МЫ ЕГО ОТПРАВИЛИ ДОМОЙ!!!.",)
        unNoDialog.show = True
        unNoDialog.sndNext()
        win()


def sc():
    sps = ['камень', 'ножницы', 'бумага']
    a = random.choice(sps)
    if a == 'камень':
        stone_.back()
        draw()

    elif a == 'ножницы':
        bg2.back()
        scissors_.back()
        unNoDialog = Dialog(screen)
        unNoDialog.message = ("ПОВЕЗЛО.......",)
        unNoDialog.show = True
        unNoDialog.sndNext()
        unNoDialog.message = ("ОН ПОСТАВИЛ НОЖНИЦЫ.",)
        unNoDialog.show = True
        unNoDialog.sndNext()
        unNoDialog.message = ("Я ВЫЙГРАЛ.",)
        unNoDialog.show = True
        unNoDialog.sndNext()
        win()

    elif a == 'бумага':
        bg2.back()
        paper_.back()
        unNoDialog = Dialog(screen)
        unNoDialog.message = ("ЧЕЕЕРТ.",)
        unNoDialog.show = True
        unNoDialog.sndNext()
        unNoDialog.message = ("ОН ПОСТАВИЛ БУМАГУю",)
        unNoDialog.show = True
        unNoDialog.sndNext()
        unNoDialog.message = ("Я ПРОИГРАЛ",)
        unNoDialog.show = True
        unNoDialog.sndNext()
        loose()


def pc():
    sps = ['камень', 'ножницы', 'бумага']
    a = random.choice(sps)
    if a == 'камень':
        bg2.back()
        stone_.back()
        unNoDialog = Dialog(screen)
        unNoDialog.message = ("УРААА.",)
        unNoDialog.show = True
        unNoDialog.sndNext()
        unNoDialog.message = ("ОН ПОСТАВИЛ КАМЕНЬю",)
        unNoDialog.show = True
        unNoDialog.sndNext()
        unNoDialog.message = ("Я ВЫЙГРАЛ, ЭТО БЫЛО ДОВОЛЬНО ЛЕГКО",)
        unNoDialog.show = True
        unNoDialog.sndNext()
        win()

    elif a == 'ножницы':
        bg2.back()
        scissors_.back()
        unNoDialog = Dialog(screen)
        unNoDialog.message = ("ЧЕЕЕРТ.",)
        unNoDialog.show = True
        unNoDialog.sndNext()
        unNoDialog.message = ("ОН ПОСТАВИЛ НОЖНИЦЫ.",)
        unNoDialog.show = True
        unNoDialog.sndNext()
        unNoDialog.message = ("Я ПРОИГРАЛ!!!.",)
        unNoDialog.show = True
        unNoDialog.sndNext()
        loose()

    elif a == 'бумага':
        paper_.back()
        draw()


def draw():
    unNoDialog = Dialog(screen)
    unNoDialog.message = ("ЭТО НИЧЬЯ.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    unNoDialog = Dialog(screen)
    unNoDialog.message = ("И ТАКОЕ БЫВАЕТ.",)
    unNoDialog.show = True
    unNoDialog.sndNext()


# и снова продолжение.....
def continue_():
    bg15.back()
    unNoDialog = Dialog(screen)
    unNoDialog.message = ("Ну чтож, победа была легкая",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    unNoDialog.message = ("Двигаемся к следущему противнику.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    unNoDialog.message = ("Надеюсь с ним будет поинтересней.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    screen.fill((0, 0, 0))
    pygame.display.flip()


# победа
def win():
    bg15.back()
    unNoDialog = Dialog(screen)
    unNoDialog.message = ("-Серега- СЮДА ПОБЕДКА!!!.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    unNoDialog.message = ("-Аня- УРА! Я так рада за тебя!.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    unNoDialog.message = (
        "-мысли- В момент я подумал, что я могу свернуть горы, но мои мысли остановил голос судьи...",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    unNoDialog.message = ("-судья- Поздравляю, вы проходите дальше к следующей игре!.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    unNoDialog.message = ("Серега- хорошо.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    screen.fill((0, 0, 0))
    end1()


# конец
def end():
    unNoDialog = Dialog(screen)
    unNoDialog.message = ("К сожалению, в этой игре вы проиграли.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    unNoDialog.message = ("Вы всегда можете начать эту игру с начала.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    unNoDialog.message = ("Мы очень стрались.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    unNoDialog.message = ("Надеемся вам понравилась.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    screen.fill((0, 0, 0))
    while True:
        printText("Я ПРОИГРАЛ,", "DejaVuSans.ttf", 35, 80, 280, red)
        printText("ИГРА ОКОНЧЕНА", "DejaVuSans.ttf", 35, 80, 310, red)
        printText("СПАСИБО", "DejaVuSans.ttf", 35, 80, 340, red)
        pygame.display.flip()
        for event in pygame.event.get():
            if event.type == pygame.MOUSEBUTTONDOWN:
                mmenu()
            elif event.type == pygame.KEYDOWN:
                mmenu()


def end1():
    unNoDialog = Dialog(screen)
    unNoDialog.message = ("я выйграл...",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    screen.fill((0, 0, 0))
    while True:
        printText("Я ПОБЕДИЛ,", "DejaVuSans.ttf", 35, 80, 280, red)
        printText("ИГРА ОКОНЧЕНА", "DejaVuSans.ttf", 35, 80, 310, red)
        printText("СПАСИБО", "DejaVuSans.ttf", 35, 80, 340, red)
        pygame.display.flip()
        for event in pygame.event.get():
            if event.type == pygame.MOUSEBUTTONDOWN:
                mmenu()
            elif event.type == pygame.KEYDOWN:
                mmenu()


# проигрыш
def loose():
    unNoDialog = Dialog(screen)
    unNoDialog.message = ("-мысли- увидев довольное лицо своего врага, я закрыл глаза....",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    unNoDialog.message = ("-мысли- неужели на этом все закончиться, неужели я больше ничего не смогу?.",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    unNoDialog.message = ("-мысли- уйдя в себя... я уже ничего не слышал....",)
    unNoDialog.show = True
    unNoDialog.sndNext()
    screen.fill((0, 0, 0))
    end_.back()


def main():
    pygame.mixer.music.play(-1)
    mmenu()
    begin = True
    keys = pygame.key.get_pressed()
    while begin:
        for event in pygame.event.get():
            if event.type == pygame.KEYDOWN:
                if event.key == keys[pygame.K_ESCAPE]:
                    begin = False
                    pygame.quit()
                    break

            if event.type == pygame.QUIT:
                begin = False
                pygame.quit()
                break


# Запуск программы
if __name__ == "__main__":
    main()
